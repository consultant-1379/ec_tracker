<div id='imfHelpBanner'>
	<h1>Support and Help</h1>
</div>
<div id='imfHelpMenu'>
	<ul>
		<li>
			<a href="contact.php">Contacts</a>
		</li>
		<li><a href="faq.php">FAQs</a></li>
	</ul>
	<hr/>
</div>