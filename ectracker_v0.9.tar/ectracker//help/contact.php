<?php session_start(); ?>
<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Strict//EN' 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd'>

<html xmlns='http://www.w3.org/1999/xhtml'>
<head>
	<?php include('helpHeader.php'); ?>
</head>
<body>
	<div id='imfHelpContainer'>
		<?php include('helpMenu.php'); ?>
		<div id='imfHelpContent'>				
			
			<p>Any issue please contact <a href="mailto:PDLENIQDEL@ex1.eemea.ericsson.se; lizhou.wang@ericsson.com">ENIQ Delivery Mgmt (LMI)</a> </p>
			
		</div>
	</div>
	<noscript><meta http-equiv='refresh' content='0; url=noscript.php'></noscript>
</body>
</html>