<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
<!--meta http-equiv='Content-Language' content='en' /-->
<meta http-equiv='X-UA-Compatible' content='IE=EmulateIE9' />
<title>Support and Help</title>
<link rel='stylesheet' type='text/css' media='screen' href='/imftool/css/reset.css' />
<link rel='stylesheet' type='text/css' media='screen' href='/imftool/css/fonts.css' />
<link rel='stylesheet' type='text/css' media='screen' href='/imftool/css/imfHelp.css' />
<link rel='shortcut icon' href='/imftool/images/favicon.ico' />	
<script type='text/javascript' src='/imftool/js/jquery-1.2.6.pack.js'></script>
<?php include "../customError.php"; ?>