<?php
session_start();
echo "<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Strict//EN' 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd'>";
?>
<html xmlns='http://www.w3.org/1999/xhtml'>
<head>
	<?php include('header.php'); ?>
</head>
<body>
				<?php 
				include('dbConnect.php'); 
				?>
		

		<div id = 'imfContainer'>
		<?php include('menu.php'); ?>
		<div id='imfContentWrapper'>
			<div id='imfContent'>
				<div id='stylized' class='myform'>
					<form name='myForm' action='ecSubmit.php' method='post' onSubmit='return validateECForm()'> 
					<!-- <form name='myForm' action='ecSubmit.php' method='post' onSubmit='return false'>-->
						<h1>Deliver EC</h1>
						<p>Deliver an EC. Fill out this form and submit it.<br />
						<span id='message'>
					
						<?php
						//if(isset($_POST['tr3_number'])){
						//echo "true";
						//}else{
						//echo "false";
						//}
						if (isset($_POST['submit_EC'])) {		
							//Submit ec info except TRs, TRs need to be submited seperately
							$fullShipmentName = $_POST['shipment_name'];
							$shipmentDetails = explode('/', $fullShipmentName);
							$shipment_name =  $shipmentDetails[0];
							$release_name =  $shipmentDetails[1];
							$submit_result = submitEC($shipment_name, $release_name, $_POST['package_name'], $_POST['r_state'], $_POST['requester'],
							$_POST['ec_type'], $_POST['eu_number'], $_POST['package_gasklink'], $_POST['pkg_tested'], $_POST['readme_link'], $_POST['readme_reviewed'], 
							$_POST['comment'], $_POST['signum']);
														

							//Submit TRs
							$ecId = $submit_result[3];
							//echo($ecId);
							$tr_id = 1;
							while(isset($_POST["tr".$tr_id."_number"])){
							//echo($_POST["tr".$tr_id."_number"]);
							//echo($_POST["tr".$tr_id."_slogan"]);
							//echo($_POST["tr".$tr_id."_origination"]);
							$tr_submit_result = submitTR($_POST["tr".$tr_id."_number"], $_POST["tr".$tr_id."_slogan"], $_POST["tr".$tr_id."_origination"], $ecId);
							if ($tr_submit_result[0] == "success") {
								//echo "
								//<span style='color:green; display:block; padding-top:15px;'>
								//	This TR <b>$tr_submit_result[1] with its EC ID </b>_<b>$tr_submit_result[2]</b> is successfully submited. 
								//</span>";
							} elseif ($tr_submit_result[0] == "fail") {
								echo "
								Insert TR <span style='color:red; display:block; padding-top:15px;'>$tr_submit_result[1]</span> failed.";
							}
							
							$tr_id++;
							}
							
							
							if ($submit_result[0] == "success") {
								//Send mails to notify CI execution
								$to = "lizhou.wang@ericsson.com";
								$subject = "EC ".$_POST['package_name']." is submited to EC Tracker for ".$_POST['shipment_name'].$_POST['release_name'];
								$message = "EC: ".$_POST['package_name']." is submited to ".$_POST['shipment_name'].$_POST['release_name']."</br> Please see <a href='http://atrcx1089.athtem.eei.ericsson.se/webpages/ectracker/'>EC Tracker</a> for details";
								$from = "lizhou.wang@ericsson.com";
								$headers = "MIME-Version: 1.0\r\n"; 
								$headers .= "Content-type: text/html; charset=iso-8859-1\r\n"; 
								$headers .= "From:" . $from;
								mail($to,$subject,$message,$headers);

								echo "
								<span style='color:green; display:block; padding-top:15px;'>
									This EC <b>$submit_result[1]</b>_<b>$submit_result[2]</b> is successfully submited. 
									</br>An notification mail has been sent to CI Execution.
								</span>";
							} elseif ($submit_result[0] == "fail") {
								echo "
								<span style='color:red; display:block; padding-top:15px;'>$submit_result[1]</span>";
							}
							
						}
						?>
						</span>
						</p>
						<table id='EC_submit_form'>
							
							<tr>
								<th><label for='shipment_name'>Shipment Name <span style='color:red;'>*</span></label></th>
								<td>
									<select id='shipment_name' name='shipment_name'>
									<option value=""></option>
							<?php
							$con = connect();
							if (!$con) {
								trigger_error(mysql_error($con), E_USER_ERROR);
								die('Could not connect: ' . mysql_error($con));
							}
							//Get shipment names from mike's database (NMI baseline database)...
							$sql_shipments_result = "SELECT DISTINCT shipment from nmi_baseline.document_details WHERE  `shipment` LIKE  '%ENIQ_E%' ORDER BY shipment DESC;";

							//echo $sql_ec_result;			
							$result_shipments = mysql_query($sql_shipments_result);

							while($shipment_result_row = mysql_fetch_array($result_shipments)){								
								$shipment_name = $shipment_result_row['shipment'];
								echo "<option value=" . $shipment_name . ">" . $shipment_name . "</option>";
							 }
							 
							 mysql_query("END");
							 // TRANSACTION END 
							 mysql_close($con);
							?>
																
							</select>
							<BR CLEAR=LEFT>
									<span id='shipmentname_error' class='error_message'></span>
								</td>
								<td class='comment'></td>
							</tr>
							

							
							<tr>
								<th><label for='package_name'>Package Name <span style='color:red;'>*</span></label></th>
								<td>
									<input type='text' id='package_name' name='package_name' maxlength='100' /><BR CLEAR=LEFT>
									<span id='packagename_error' class='error_message'></span>
								</td>
								<td class='comment'>e.g. mediation_gateway</td>
							</tr>
							
							<tr>
								<th><label for='r_state'>R-state <span style='color:red;'>*</span></label></th>
								<td>
									<input type='text' id='r_state' name='r_state' maxlength='60' /><BR CLEAR=LEFT>
									<span id='rstate_error' class='error_message'></span>
								</td>
								<td class='comment'>e.g. R2H10_EC30</td>
							</tr>
							
							<tr>
								<th><label for='resquster'>Requester <span style='color:red;'>*</span></label></th>
								<td class="input_td">
									<select id='requester' name='requester'>
									<option value=""></option>
									<option value="FT">FT</option>
									<option value="ST">ST</option>
									<option value="FOA">FOA</option>
									</select>
									<BR CLEAR=LEFT>
									<span id='requester_error' class='error_message'></span>
								</td>
								<td class='comment'></td>
							</tr>
							
												
							<tr>
								<th>
									<input type='radio' id='mws_ec' name='ec_type' value='mws_ec'  style='width:20px; border:0px; position:relative; left:95%;'/>
								</th>
								<td>This is a MWS EC</td>
								<td class='comment' rowspan='2'>
									<span></span>
									<span></span>
								</td>					
							</tr>

							<tr>
								<th>
									<input type='radio' id='hot_ec' name='ec_type' value='hot_ec' checked='checked' style='width:20px; border:0px; position:relative; left:95%;'/>
								</th>
								<td>This is a HOT EC</td>
							</tr>
							<tr id='fm_form'>
								<th><label for='eu_number'>EU number <span style='color:red;'>*</span></label></th>
								<td class="input_td">
									<input type='text' id='eu_number' name='eu_number' maxlength='10'
									/><BR CLEAR=LEFT>
									<span id='eunumber_error' class='error_message'></span>
								</td>
								<td class='comment'>e.g. 2</td>
							</tr>
							

							<tr>
								<th><label for='package_gasklink'>Package Gask Link <span style='color:red;'>*</span></label></th>
								<td colspan=2 class="input_td">
									<input type='text' id='package_gasklink' name='package_gasklink' maxlength='250' style="width:765px;"/><BR CLEAR=LEFT>
									<span id='packagegasklink_error' class='error_message'></span>
								</td>
							</tr>
							

							<tr>
								<th><label for='package_tested'>Is this package tested? <span style='color:red;'>*</span></label></th>
								<td class="input_td">
								<table>
								<tr>
								<th style='height:24px;'><input type='radio' id='pkg_tested_no' name='pkg_tested' value='pkg_tested_no'  checked='checked'  style='width:20px; border:0px; position:relative; left:0%;'/> <span style='position:relative; left:-60%;'>No</span>
							
								</th>	
								<th style='height:0px;'><input type='radio' id='pkg_tested_yes' name='pkg_tested' value='pkg_tested_yes'  style='width:20px; border:0px; position:relative; left:-40%;'/><span style='position:relative; left:-95%;'>Yes</span>
								</th>
								</tr>								
								</table>
								<span id='packagetested_error' class='error_message'></span>
								</td>
								<td class='comment'> </td>
							</tr>

							<tr>
								<th><label for='readme_link'>Readme Link <span style='color:red;'>*</span></label></th>
								<td colspan=2 class="input_td">
									<input type='text' id='readme_link' name='readme_link' maxlength='250' style="width:765px;"/><BR CLEAR=LEFT>
									<span id='readmelink_error' class='error_message'></span>
								</td>
							</tr>
							
							<tr>
								<th><label for='package_tested'>Is this readme reviewed? <span style='color:red;'>*</span></label></th>
								<td class="input_td">
								
								<table>
								<tr>
								<th style='height:24px;'><input type='radio' id='readme_reviewed_no' name='readme_reviewed' value='readme_reviewed_no'  checked='checked'  style='width:20px; border:0px; position:relative; left:0%;'/> <span style='position:relative; left:-60%;'>No</span>
								</th>
								<th style='height:0px;'><input type='radio' id='readme_reviewed_yes' name='readme_reviewed' value='readme_reviewed_yes'  style='width:20px; border:0px; position:relative; left:-40%;'/><span style='position:relative; left:-95%;'>Yes</span>
								</th>
								</tr>
								</table>
								<span id='readmereviewed_error' class='error_message'></span>
								</td>
								<td class='comment'> </td>
							</tr>


							<tr id="tr_0">
							<th> <label for='tr_number'>TR Number <span style='color:red;'>*</span></label></th>
							<td colspan=2>
							<table class="TRtable">						
								<td class="TR_td_top">
									<input type='text' id='tr1_number' class="tr_number" name='tr1_number' maxlength='60' /><BR CLEAR=LEFT>
									<span id='tr1number_error' class='error_message'></span>
								</td>

							<th><label for='tr_slogan'>Slogan <span style='color:red;'>*</span></label></th>
								<td class="TR_td">
									<input type='text' id='tr1_slogan' name='tr1_slogan' maxlength='200'/><BR CLEAR=LEFT>
									<span id='tr1slogan_error' class='error_message'></span>
								</td>

							<th><label for='tr_origination'>Origination <span style='color:red;'>*</span></label></th>
								<td class="TR_td">
									<input type='text' id='tr1_origination' name='tr1_origination' maxlength='60'/><BR CLEAR=LEFT>
									<span id='tr1origination_error' class='error_message'></span>
								</td>
							<td class="TR_td"><div class = "addtr_div_place" id = "addtr_div_place"><div class="addtr_button" id="addtr_button" onclick="addTR(this);">Add</div></div></td>
							</table>
							</td>
							</tr>
							
							<tr>
								<th><label for='comment'>Comment<span style='color:red;'>&nbsp&nbsp</span></label></th>
								<td colspan=2 class="input_td">
									<textarea type='text' id='comment' name='comment' maxlength='250'></textarea><BR CLEAR=LEFT>
									<span id='comment_error' class='error_message'></span>
								</td>
							</tr>
							
							<tr>
								<th><label for='signum'>Signum(s) <span style='color:red;'>*</span></label></th>
								<td>
									<input type='text' id='signum' name='signum' maxlength='100' /><BR CLEAR=LEFT>
									<span id='signum_error' class='error_message'></span></td>
								<td class='comment'>e.g. EWANLIZ</td>
							</tr>

							
						</table>
						

						<input type='hidden' name='submit_EC' id='submit_EC' value='true' />
						<p>
							 <button type='submit'>Submit</button>
						</p>
					</form>	
				</div>
			</div>
		</div>	
		<?php include('footer.php'); ?>	
	</div>	
	<script type='text/javascript' src='js/ECSubmit.js'></script>
	<noscript><meta http-equiv='refresh' content='0; url=noscript.php'></noscript>
</body>
</html>

<?php

function submitEC($shipmentName, $releaseName, $packageName, $rState, $requester, $ecType, $euNumber, $packageGaskLink, $pkgTested, $readmeLink, $readmeReviewed, $comment, $signum) {
	$con = connect();
	if (!$con) {
		trigger_error(mysql_error($con), E_USER_ERROR);
		die('Could not connect: ' . mysql_error($con));
	}
	
	$error_message = "";
	$validate_result = true;
	
	$shipmentName = trim($shipmentName);
	$releaseName = trim($releaseName);
	$packageName = trim($packageName);
	$rState = trim($rState);
	$requester = trim($requester);
	$ecType = trim($ecType);
	$euNumber = trim($euNumber);
	$packageGaskLink = trim($packageGaskLink);
	$pkgTested = trim($pkgTested);
	$readmeLink = trim($readmeLink);
	$readmeReviewed = trim($readmeReviewed);
	$comment = trim($comment);
	$signum = trim($signum);

		
		//chage varible values into data table format.
		if($ecType == "mws_ec"){
		$ecType = "MWS EC";
		$euNumber = "";  //there is no EU number for a MWS EC
		}else if($ecType == "hot_ec"){
		$ecType = "HOT EC";
		}
		
		if($pkgTested == "pkg_tested_no"){
		$pkgTested = "NO";
		}
		else if($pkgTested == "pkg_tested_yes"){
		$pkgTested = "YES";
		}
		
		if($readmeReviewed == "readme_reviewed_no"){
		$readmeReviewed = "NO";
		}
		else if($readmeReviewed == "readme_reviewed_yes"){
		$readmeReviewed = "YES";
		}
		
		//echo("<br>");
		//echo($ecType);
		//echo($pkgTested);
		//echo($readmeReviewed);
		$submit_result = insertECIntoDatabase($shipmentName, $releaseName, $packageName, $rState, $requester, $ecType, $euNumber, $packageGaskLink, $pkgTested, $readmeLink, $readmeReviewed,$comment, $signum);

		//$submit_result = array("success", "cep", "testtt");
		mysql_close($con);
	    return $submit_result;
}

function insertECIntoDatabase($shipmentName, $releaseName, $packageName, $rState, $requester, $ecType, $euNumber, $packageGaskLink, $pkgTested, $readmeLink, $readmeReviewed, $comment, $signum)
{
	$con = connect();
	if (!$con) {
		trigger_error(mysql_error($con), E_USER_ERROR);
		die('Could not connect: ' . mysql_error($con));
	}
	
	// TRANSACTION START
	mysql_query("BEGIN");
	
	date_default_timezone_set("Europe/Dublin");
	$submitDate = date("Y-m-d H:i:s");
	$ecId = $packageName.' '.$rState.' '.timetostring($submitDate);
		
	$sqlEcID = mysql_real_escape_string($ecId);
     	$sqlShipmentName = mysql_real_escape_string($shipmentName);
	$sqlReleaseName = mysql_real_escape_string($releaseName);
	$sqlPackageName = mysql_real_escape_string($packageName);
	$sqlRState = mysql_real_escape_string($rState);
	$sqlRequester = mysql_real_escape_string($requester);
	$sqlEcType = mysql_real_escape_string($ecType);
	$sqlEuNumber = mysql_real_escape_string($euNumber);
	$sqlPackageGaskLink = mysql_real_escape_string($packageGaskLink);
	$sqlPkgTested = mysql_real_escape_string($pkgTested);
	$sqlReadmeLink = mysql_real_escape_string($readmeLink);
	$sqlReadmeReviewed = mysql_real_escape_string($readmeReviewed);
	$sqlComment = mysql_real_escape_string($comment);
	$sqlSignum = mysql_real_escape_string($signum);
	//$sqlSubmitDate = mysql_real_escape_string($submitDate);

	
	
	$sql_submit_ec = "INSERT INTO `eniq_events_ecs`.`ecs` (`EC_ID`, `SHIPMENT_NAME`, `RELEASE_NAME`, `PACKAGE_NAME`, `R_STATE`, `REQUESTER`, `EC_TYPE`, `EU_NUMBER`, `PACKAGE_GASKLINK`, `PACKAGE_TESTED`, `README_LINK`, `README_REVIEWED`, `COMMENT`, `SIGNUM`, `DELIVERED_TO_DM`, `DELIVERED_TO_ST`, `DELIVERED_TO_FOA`) 
	VALUES ('$sqlEcID', '$sqlShipmentName', '$sqlReleaseName', '$sqlPackageName', '$sqlRState', '$sqlRequester', '$sqlEcType', '$sqlEuNumber', '$sqlPackageGaskLink', '$sqlPkgTested', '$sqlReadmeLink', '$sqlReadmeReviewed', '$sqlComment', '$sqlSignum', '$submitDate', NULL, NULL);";
	
	
	//echo($sql_submit_ec);
	
	$result_submit_ec = mysql_query($sql_submit_ec);

	
	$insert_result = array("fail", "Database Unknown Error, please contact ENIQ Delivery Mgmt (LMI).");
	if($result_submit_ec) {
		mysql_query("COMMIT");
		$insert_result = array("success", $sqlPackageName, $sqlRState, $sqlEcID);
	} else {
		trigger_error(mysql_error($con), E_USER_ERROR);
		mysql_query("ROLLBACK");
		$insert_result = array("fail", "Database Failure: InsertComponentToDatabase Transaction Error.");
	}
	mysql_query("END");
	// TRANSACTION END 
	mysql_close($con);
	return $insert_result;
	
}

function timetostring($str){
     $cliptime=explode("-",$str);
     $result="";
     for($i=0;$i<count($cliptime);$i++){
       $result=$result.$cliptime[$i];
     }
  return $result;
 }

 //Insert TRs
 function submitTR($trNumber, $trSlogan, $trOrigination, $ecId) {
	$con = connect();
	if (!$con) {
		trigger_error(mysql_error($con), E_USER_ERROR);
		die('Could not connect: ' . mysql_error($con));
	}
	
	$error_message = "";
	$validate_result = true;
	
	$trNumber = trim($trNumber);
	$trSlogan = trim($trSlogan);
	$trOrigination = trim($trOrigination);
	$ecId = trim($ecId);
	
		$submit_result = insertTRIntoDatabase($trNumber, $trSlogan, $trOrigination, $ecId);

		//$submit_result = array("success", "cep", "testtt");
		mysql_close($con);
	    return $submit_result;
}


function insertTRIntoDatabase($trNumber, $trSlogan, $trOrigination, $ecId)
{
	$con = connect();
	if (!$con) {
		trigger_error(mysql_error($con), E_USER_ERROR);
		die('Could not connect: ' . mysql_error($con));
	}
	
	// TRANSACTION START
	mysql_query("BEGIN");
	
	
	
	$sqlTrNumber = mysql_real_escape_string($trNumber);
	$sqlTrSlogan = mysql_real_escape_string($trSlogan);
	$sqlTrOrigination = mysql_real_escape_string($trOrigination);
	$sqlEcID = mysql_real_escape_string($ecId);
	
	//INSERT INTO `eniq_events_ecs`.`trs` (`TR_NUMBER`, `SLOGAN`, `ORIGINATION`, `EC_ID`) VALUES ('HQ12333', 'SSSSS', 'OOOOOO', 'SDDFG  SDF 09123849');		
	$sql_submit_tr = "INSERT INTO `eniq_events_ecs`.`trs` (`TR_NUMBER`, `SLOGAN`, `ORIGINATION`, `EC_ID`) 
	VALUES ('$sqlTrNumber', '$sqlTrSlogan', '$sqlTrOrigination', '$sqlEcID');";
	
	
	$result_submit_tr = mysql_query($sql_submit_tr);

	
	$insert_result = array("fail", "Database Unknown Error, please contact IMF Team.");
	if($result_submit_tr) {
		mysql_query("COMMIT");
		$insert_result = array("success", $sqlTrNumber, $sqlEcID);
	} else {
		trigger_error(mysql_error($con), E_USER_ERROR);
		mysql_query("ROLLBACK");
		$insert_result = array("fail", "Database Failure: InsertComponentToDatabase Transaction Error.");
	}
	mysql_query("END");
	// TRANSACTION END 
	mysql_close($con);
	return $insert_result;
	
}

?>
?>
?>
?>