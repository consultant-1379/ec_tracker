<?php	
							$to = "lizhou.wang@ericsson.com";
								$subject = "Internal Release Mail: ENIQ Events 12.1 Ship 2.1.8 EU12 (R2H/12)";
								//$message = "EC mediation_gateway is submited to EC Tracker for ENIQ_E11.31.3.7 </br> Please see <a href='http://atrcx1089.athtem.eei.ericsson.se/webpages/ectracker/'>EC Tracker</a> for more details";
$message = "<html>
	<head>
		<title>EC Release Mail</title>
	</head>
	<body>
		<div>
			<span style='font-size:12px;'><span style='color: rgb(255, 0, 0);'><span style='font-family: tahoma, geneva, sans-serif;'>Update 1: Updated with new readme.</span></span></span></div>
		<div>
			<span style='font-size:12px;'><span style='color: rgb(255, 0, 0);'><span style='font-family: tahoma, geneva, sans-serif;'>Update 2: Updated with new readme, package and TRs.</span></span></span></div>
		<div>
			<span style='font-size:12px;'><span style='color: rgb(255, 0, 0);'><span style='font-family: tahoma, geneva, sans-serif;'>Update 3: Updated with new readme, package and TR</span></span></span></div>
		<div>
			&nbsp;</div>
		<div>
			<span style='font-size:12px;'><strong><span style='color: rgb(255, 0, 0);'><span style='font-family: tahoma, geneva, sans-serif;'>Internal Delivery Mail: HOT ENIQ Package for ENIQ Events 2.2.15 R3T/2 EU02 Release - ST</span></span></strong></span></div>
		<div>
			&nbsp;</div>
		<div dir='ltr' style='margin-left: 40px;'>
			<span style='font-size:12px;'><span style='color: rgb(128, 0, 0);'><span style='font-family: tahoma, geneva, sans-serif;'><strong>Product Delivery information: </strong>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; M_E_LTEES_R4G_b302.tpi</span></span></span></div>
		<div>
			&nbsp;</div>
		<div style='margin-left: 40px;'>
			<span style='font-size:12px;'><span style='color: rgb(128, 0, 128);'><span style='font-family: tahoma, geneva, sans-serif;'><strong>Reason: &nbsp;</strong>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; For TR fixes HQ42060, HQ37676, HQ44722, HQ44135, HQ46704, HQ41677, HQ46957,HQ56366, HQ56815, HQ57944, HQ61303, HQ63745</span></span></span></div>
		<div>
			&nbsp;</div>
		<div style='margin-left: 40px;'>
			<span style='font-size:12px;'><span style='color: rgb(128, 0, 128);'><span style='font-family: tahoma, geneva, sans-serif;'><strong>Requester: &nbsp; &nbsp;</strong> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; FOA&nbsp;</span></span></span></div>
		<div>
			&nbsp;</div>
		<div>
			<span style='font-size:12px;'><span style='font-family: tahoma, geneva, sans-serif;'>1. Download Information (Please ensure that 2.2.15-2 EU2 is installed before installing the below HOT EC)&nbsp;</span></span></div>
		<div>
			<span style='font-size:12px;'><span style='font-family: tahoma, geneva, sans-serif;'><a href='http://gask2web.ericsson.se/pub/get?DocNo=2/19089-CXC1731896&amp;Lang=X&amp;Rev=HL&amp;Format=PKZIPV2R04'>http://gask2web.ericsson.se/pub/get?DocNo=2/19089-CXC1731896&amp;Lang=X&amp;Rev=HL&amp;Format=PKZIPV2R04</a></span></span></div>
		<div>
			&nbsp;</div>
		<div>
			<span style='font-size:12px;'><span style='font-family: tahoma, geneva, sans-serif;'>2. Readme:&nbsp;</span></span></div>
		<div>
			<span style='font-size:12px;'><a href='http://gask2web.ericsson.se/pub/get?DocNo=154/10264-AOM901079&amp;Lang=EN&amp;Rev=AM&amp;Format=ASCII'><span style='font-family: tahoma, geneva, sans-serif;'>http://gask2web.ericsson.se/pub/get?DocNo=154/10264-AOM901079&amp;Lang=EN&amp;Rev=AM&amp;Format=ASCII</span></a></span></div>
		<div>
			&nbsp;</div>
		<div>
			&nbsp;</div>
		<div>
			&nbsp;</div>
		<div>
			<span style='font-size:12px;'><span style='font-family: tahoma, geneva, sans-serif;'>3. Included TR Fixes:</span></span></div>
		<div>
			<span style='font-size:12px;'><strong><span style='color: rgb(128, 0, 0);'><span style='font-family: tahoma, geneva, sans-serif;'>TR number &nbsp; &nbsp; &nbsp;Slogan &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; TR Origination&nbsp;</span></span></strong></span></div>
		<div>
			<span style='font-size:12px;'><span style='color: rgb(128, 0, 0);'><span style='font-family: tahoma, geneva, sans-serif;'>HQ56366 &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; LTE ES Processing out of Sync after missing ROP EE 12.2.15 &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;EE12.2FOATELSTRAT-0016</span></span></span></div>
		<div>
			<span style='font-size:12px;'><span style='color: rgb(128, 0, 0);'><span style='font-family: tahoma, geneva, sans-serif;'>HQ56815 &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 5 mins LTEES not working with utc + offset &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;EE12.2-FOA-SPRT-T-0022</span></span></span></div>
		<div>
			<span style='font-size:12px;'><span style='color: rgb(128, 0, 0);'><span style='font-family: tahoma, geneva, sans-serif;'>HQ57944 &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; LTEES EOF error &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;EE12.2FOATELSTRAL-0006</span></span></span></div>
		<div>
			<span style='font-size:12px;'><span style='color: rgb(128, 0, 0);'><span style='font-family: tahoma, geneva, sans-serif;'>HQ61303 &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; CTRS deleting file and sym link for the rop 2355-0000 before getting processed by LTEES &nbsp; &nbsp;EE12.2-FT-0083</span></span></span></div>
		<div>
			<span style='font-size:12px;'><span style='color: rgb(128, 0, 0);'><span style='font-family: tahoma, geneva, sans-serif;'>HQ42060 &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Cache to be redesigned for LTE_ES to avoid WF aborting and speed up performance &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; EE11-FT-0624</span></span></span></div>
		<div>
			<span style='font-size:12px;'><span style='color: rgb(128, 0, 0);'><span style='font-family: tahoma, geneva, sans-serif;'>HQ37676 &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Investigate poor performance of LTEES workflows under load of 500 eNodeBs &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;EE12.2-FT-0071&nbsp;</span></span></span></div>
		<div>
			<span style='font-size:12px;'><span style='color: rgb(128, 0, 0);'><span style='font-family: tahoma, geneva, sans-serif;'>HQ44722 &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; EE 12.2.15 EU2 LTEES WF aborting due to &quot;No topology datastore files available&quot; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;EE12.2-FOA-SPRT-T-0012&nbsp;</span></span></span></div>
		<div>
			<span style='font-size:12px;'><span style='color: rgb(128, 0, 0);'><span style='font-family: tahoma, geneva, sans-serif;'>HQ44135 &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; LTE ES is not using the common libraries package for ENIQ Events &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; EE11-FT-0625&nbsp;</span></span></span></div>
		<div>
			<span style='font-size:12px;'><span style='color: rgb(128, 0, 0);'><span style='font-family: tahoma, geneva, sans-serif;'>HQ46704 &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Further memory alloctation requried for the LTEES ECs to prevent falling into backlog &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;EE12-ST-0294&nbsp;</span></span></span></div>
		<div>
			<span style='font-size:12px;'><span style='color: rgb(128, 0, 0);'><span style='font-family: tahoma, geneva, sans-serif;'>H415677 &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Issue with EC1 Service coming online after Eniq Events 12.2.15 UG and EU1 UG &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;EE12.2FOATELSTRAT-0003&nbsp;</span></span></span></div>
		<div>
			<span style='font-size:12px;'><span style='color: rgb(128, 0, 0);'><span style='font-family: tahoma, geneva, sans-serif;'>HQ46957 &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Issue with LTE ES processing 3 (5min ROPS) &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;EE12.2FOATELSTRAT-0012&nbsp;</span></span></span></div>
		<div>
			<span style='font-size:12px;'><span style='color: rgb(128, 0, 0);'><span style='font-family: tahoma, geneva, sans-serif;'>HQ63745 &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; EE: LTEES wfs abort trying to move files - M_E_LTEES_R4G_b300 (DEFTEEB-599) &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;EE12-ST-0318</span></span></span></div>
		<div>
			&nbsp;</div>
		<div>
			&nbsp;</div>
		<div>
			<span style='font-size:12px;'><strong><span style='font-family: tahoma, geneva, sans-serif;'>ENIQ Delivery Mgmt (LMI)&nbsp;</span></strong></span></div>
		<div>
			&nbsp;</div>
		<div>
			<span style='font-size:12px;'><span style='font-family: tahoma, geneva, sans-serif;'>Ericsson LMI&nbsp;</span></span></div>
		<div>
			<span style='font-size:12px;'><span style='font-family: tahoma, geneva, sans-serif;'>Delivery Management&nbsp;</span></span></div>
		<div>
			<span style='font-size:12px;'><span style='font-family: tahoma, geneva, sans-serif;'>Athlone, Westmeath,&nbsp;</span></span></div>
		<div>
			<span style='font-size:12px;'><span style='font-family: tahoma, geneva, sans-serif;'>Ireland</span></span></div>
		<div>
			&nbsp;</div>
		<div>
			<span style='font-size:12px;'><span style='font-family: tahoma, geneva, sans-serif;'>http://www.ericsson.com</span></span></div>
	</body>
</html>
";								
$from = "lizhou.wang@ericsson.com";
								
								$headers = "MIME-Version: 1.0\r\n"; 
								$headers .= "Content-type: text/html; charset=iso-8859-1\r\n"; 
								$headers .= "From:" . $from;
								mail($to,$subject,$message,$headers);
?>