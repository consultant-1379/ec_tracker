	<div id='imfFooterWrapper'>
		<div id='imfFooter'>
			ENIQ Events EC Tracker<br />Version 0.9
		</div>
	</div>