<?php
function connect(){

	$host = "159.107.173.47"; //host name
	$username = "ectracker"; //username
	$password = "shroot"; //password
	$databasename = "eniq_events_ecs"; //db name
	//connect to database
	$con = mysql_connect("$host", "$username", "$password");
	//echo $con;
	mysql_select_db("$databasename") or die("Cannot select DB");
	mysql_set_charset('utf8');
	return $con;
}
?>